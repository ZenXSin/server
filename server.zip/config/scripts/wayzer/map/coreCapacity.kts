@file:Depends("coreMindustry/utilMapRule", "修改核心单位,单位属性")

import arc.graphics.Colors
import coreMindustry.lib.broadcast
import coreMindustry.lib.game
import kotlinx.coroutines.Dispatchers
import mindustry.ctype.ContentType
import mindustry.Vars
import mindustry.Vars.content
import mindustry.content.Blocks
import mindustry.content.UnitTypes
import mindustry.content.Fx.launch
import mindustry.core.ContentLoader
import mindustry.ctype.Content
import mindustry.ctype.MappableContent
import mindustry.game.EventType
import mindustry.game.Team
import mindustry.world.blocks.storage.CoreBlock
import java.lang.reflect.Modifier
import kotlin.reflect.KMutableProperty0

val bakMap = mutableMapOf<KMutableProperty0<*>, Any?>()

/**Should invoke in [Dispatchers.game] */
fun <T : Content, R : T> newContent(origin: T, block: (origin: T) -> R): R {
    val bak = content
    content = object : ContentLoader() {
        override fun transformName(name: String?) = bak?.transformName(name) ?: name
        override fun handleContent(content: Content?) = Unit
        override fun handleMappableContent(content: MappableContent?) = Unit
    }
    return try {
        block(origin).also { new ->
            origin::class.java.fields.forEach {
                if (!it.declaringClass.isInstance(new)) return@forEach
                if (Modifier.isPublic(it.modifiers) && !Modifier.isFinal(it.modifiers)) {
                    it.set(new, it.get(origin))
                }
            }
        }
    } finally {
        content = bak
    }
}

fun <T> registerMapRule(field: KMutableProperty0<T>, checkRef: Boolean = true, valueFactory: (T) -> T) {
    synchronized(bakMap) {
        @Suppress("UNCHECKED_CAST")
        val old = (bakMap[field] as T?) ?: field.get()
        val new = valueFactory(old)
        if (field !in bakMap && checkRef && new is Any && new === old)
            error("valueFactory can't return the same instance for $field")
        field.set(new)
        bakMap[field] = old
    }
}

fun reset(){
    synchronized(bakMap) {
        bakMap.forEach { (field, bakValue) ->
            @Suppress("UNCHECKED_CAST")
            (field as KMutableProperty0<Any?>).set(bakValue)
        }
        bakMap.clear()
    }
}

listen<EventType.ResetEvent> {
    reset()
}
onDisable{
    reset()
}

val ca by config.key(1000000, "核心容量大小")

listen<EventType.PlayEvent> {
    var ca:Int = state.rules.tags.getInt("@itemCapacity", ca)
}

ca.toInt()

fun changeCoreCapacity(){
    launch(Dispatchers.game){
    if (ca >= 2147483647 || ca <= 0)
        return@launch
        else
        contextScript<coreMindustry.UtilMapRule>().apply {
            registerMapRule((Blocks.coreShard as CoreBlock)::itemCapacity) { ca }
            registerMapRule((Blocks.coreFoundation as CoreBlock)::itemCapacity) { ca }
            registerMapRule((Blocks.coreNucleus as CoreBlock)::itemCapacity) { ca }

            registerMapRule((Blocks.coreAcropolis as CoreBlock)::itemCapacity) { ca }
            registerMapRule((Blocks.coreBastion as CoreBlock)::itemCapacity) { ca }
            registerMapRule((Blocks.coreCitadel as CoreBlock)::itemCapacity) { ca }

            broadcast("核心资源容量已修改".with())
        }
    }
}