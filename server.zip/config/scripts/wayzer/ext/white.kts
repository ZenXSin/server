package coreMindustry

import arc.util.Align
import coreLibrary.lib.util.loop
import mindustry.gen.Groups
import java.time.Duration
import cf.wayzer.placehold.PlaceHoldApi.with
import mindustry.net.Administration


listen<EventType.PlayerJoin> {
    val uuid = it.player.uuid()
    val name = it.player.name
    val threed = getThreeId(name)
    val threeid = stripText(threed.toString())
    if (PlayerData.findById(uuid)?.profile == null) { 
    broadcast("[cyan]玩家{player.name}您未绑定，请您先绑定。您的3位id是{threeid}".with("player" to it.player ,"threeid" to threeid))
     } else broadcast("[cyan]玩家{player.name}您已绑定，祝您游玩愉快您的3位id是{threeid}".with("player" to it.player ,"threeid" to threeid))
}
fun getThreeId(playerName: String): String? {
    val index = playerName.indexOf("|")
    if (index == -1 || index + 4 > playerName.length) {
        return null
    }
    return playerName.substring(index + 1, index + 4)
}
fun stripText(text: String): String {
    val ansiRegex = "\u001B\\[[;\\d]*m".toRegex()
    val escapeRegex = "\u001B|\\[|\\]|\\(|\\)|\\s".toRegex()
    return text.replace(ansiRegex, "").replace(escapeRegex, "")
}