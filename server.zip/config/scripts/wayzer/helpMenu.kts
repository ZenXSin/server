@file:Depends("coreMindustry/utilNext")
package wayzer
//宅博士©版权所有,未经允许禁止擅自修改,否则后果自负
import coreMindustry.lib.RootCommands.getSubCommands
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min

command("help", "帮助") {
    usage = "[页码]"
    type = CommandType.Client
    aliases = listOf("帮助")
    body {
        val context = this
        var page = context.arg.firstOrNull()?.toIntOrNull() ?: 1
        fun sendMenu() {
            launch(Dispatchers.game) {
                contextScript<coreMindustry.UtilNext>().sendMenuBuilder<Unit>(player!!, Int.MAX_VALUE, "[#00ff00]命令菜单", "[cyan]点击即可执行命令\n[gold]快捷指令 欢迎使用！") {
                    var count = 1
                    getSubCommands(context).values.toSet().filter { it.permission.isBlank() || context.hasPermission(it.permission) }.forEach {
                        count++
                        if (count - 1 !in 10 * (page - 1)..10 * page) return@forEach
                        val prefix2 = prefix.removeSuffix("help ").removeSuffix("帮助 ")
                        add(listOf("[yellow]${prefix2}${it.name}  [scarlet]${it.aliases}\n[pink]${it.usage}\n[cyan]${it.description}" to { it.invoke(context) }))
                }
                add(listOf(
                    "[gold]上一页" to {
                        page = max(page - 1, 1)
                        sendMenu()
                    },
                    "$page / ${ceil(getSubCommands(context).values.toSet().filter { it.permission.isBlank() || context.hasPermission(it.permission) }.size * 1f / 10).toInt()}" to {},
                    "[cyan]下一页" to {
                        page = min(page + 1, ceil(getSubCommands(context).values.toSet().filter { it.permission.isBlank() || context.hasPermission(it.permission) }.size * 1f / 10).toInt())


                        sendMenu()
                    }))
                
                add(listOf("[scarlet]关闭" to { }))
                }
            }
        }
        sendMenu()
    }
}