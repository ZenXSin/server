package wayzer.reGrief

fun Player.isOk(): Boolean {
    val ok = PlayerData.findById(uuid())?.profile != null
    if (!ok) Call.infoMessage(
        con, """本服务器已开启白名单验证
                [red]请绑定账号后再进行操作[]
                绑定账号请私聊饭团[green]绑定[]
                验证消息填写'绑定服务器'""".trimIndent()
    )
    return ok
}

registerActionFilter {
    it.player.isOk()
}
