## 扩展工具库
存储一些常用工具函数，但不是必需功能
请通过`@file:Import("@coreMindustry/util/trackBuilding.kt", sourceFile = true)`导入