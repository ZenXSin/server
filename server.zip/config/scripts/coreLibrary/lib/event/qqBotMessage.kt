package qqBot

import cf.wayzer.scriptAgent.Event
import cf.wayzer.scriptAgent.define.Script

class qqBotMessage(val Message: String) : Event {
    override val handler = Companion
    companion object : Event.Handler()
}
